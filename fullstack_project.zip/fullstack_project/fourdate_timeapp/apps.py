from django.apps import AppConfig


class FourdateTimeappConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "fourdate_timeapp"
