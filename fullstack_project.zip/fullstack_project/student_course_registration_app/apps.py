from django.apps import AppConfig


class StudentCourseRegistrationAppConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "student_course_registration_app"
